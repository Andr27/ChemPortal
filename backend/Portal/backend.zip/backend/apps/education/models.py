from django.db import models
from django.contrib.auth import get_user_model
from Portal.choices import ModerationStatus
from apps.categories.models import Category


User = get_user_model()


class EducationSection(models.Model):

    title = models.CharField(max_length=100)
    description = models.TextField(blank=True)

    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='education_sections')
    created_at = models.DateTimeField(auto_now_add=True)

    status = models.CharField(max_length=20, choices=ModerationStatus.choices, default=ModerationStatus.DRAFT)

    category = models.ForeignKey(Category,
                                 on_delete=models.SET_NULL,
                                 null=True,
                                 blank=True,
                                 related_name='sections'
                                 )
    rating = models.FloatField(default=0.0)
    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.title



class SectionMaterial(models.Model):
    MATERIAL_TYPES = [
        ("text", "Текст"),
        ("video", "Видео"),
        ("link", "Ссылка")
    ]

    section = models.ForeignKey(EducationSection, on_delete=models.CASCADE, related_name='materials')
    title = models.CharField(max_length=255)

    type = models.CharField(max_length=100, choices=MATERIAL_TYPES)
    image = models.ImageField(upload_to='materials/', null=True, blank=True)
    content = models.TextField(blank=True)
    external_url = models.URLField(blank=True)

    order = models.PositiveIntegerField(default=0)

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["order", "created_at"]

    def __str__(self):
        return self.title



class Course(models.Model):
    section = models.ForeignKey(EducationSection, on_delete=models.CASCADE, related_name='courses')
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='courses')
    created_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=ModerationStatus.choices, default=ModerationStatus.DRAFT)
    reject_comment = models.TextField(blank=True, default='')
    rating = models.FloatField(default=0.0)
    reviews_count = models.PositiveIntegerField(default=0)
    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.title



class Chapter(models.Model):
    course = models.ForeignKey(
        Course,
        on_delete=models.CASCADE,
        related_name='chapters'
    )
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    order = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['order', 'created_at']

    def __str__(self):
        return f"{self.course.title} — {self.title}"


class Lesson(models.Model):
    LESSON_TYPES = [
        ('lecture', 'Лекция'),
        ('practice', 'Практика'),
        ('link', 'Ссылка'),
    ]

    chapter = models.ForeignKey(
        Chapter,
        on_delete=models.CASCADE,
        related_name='lessons'
    )
    title = models.CharField(max_length=255)
    type = models.CharField(max_length=100, choices=LESSON_TYPES)
    content = models.TextField(blank=True)
    external_url = models.URLField(blank=True)
    order = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['order', 'created_at']

    def __str__(self):
        return f"{self.chapter.title} — {self.title}"





class SectionMaterialImage(models.Model):
    material = models.ForeignKey(
        SectionMaterial,
        on_delete=models.CASCADE,
        related_name='images'
    )
    image = models.ImageField(upload_to='materials/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Image for material {self.material_id}"



class LessonComments(models.Model):
    lesson = models.ForeignKey(
        Lesson,
        on_delete=models.CASCADE,
        related_name='comments'
    )
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='lesson_comments')
    text = models.TextField()
    parent = models.ForeignKey('self', null=True, blank=True, on_delete=models.CASCADE, related_name='children')
    is_deleted = models.BooleanField(default=False)
    is_pinned = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["created_at"]
        verbose_name = "Комментарий к уроку"
        verbose_name_plural = "Комментарии к уроку"


from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType

class ExpertReview(models.Model):
    VOTE_CHOICES = [
        ('approve', 'Одобрить'),
        ('reject', 'Отклонить'),
        ('request_changes', 'Запросить правки'),
    ]


    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')

    expert = models.ForeignKey(
        User, on_delete=models.CASCADE,
        related_name='expert_reviews'
    )
    vote = models.CharField(max_length=20, choices=VOTE_CHOICES)
    comment = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('content_type', 'object_id', 'expert')
        verbose_name = 'Экспертный отзыв'
        verbose_name_plural = 'Экспертные отзывы'

    def __str__(self):
        return f"{self.expert.email} → {self.content_object} ({self.vote})"
